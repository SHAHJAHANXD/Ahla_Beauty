<script src="{{ asset('assets/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('assets/js/tiny-slider.js') }}"></script>
<script src="{{ asset('assets/js/aos.js.js') }}"></script>
<script>eval(mod_pagespeed_W5JmgKXb9D);</script>
<script>eval(mod_pagespeed_InsmBRpQ_R);</script>
<script>eval(mod_pagespeed_m5dg2a90TW);</script>
<script>eval(mod_pagespeed_H_S_Je0Ul9);</script>
<script>eval(mod_pagespeed_$xbQGU6UQW);</script>

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag() { dataLayer.push(arguments); }
    gtag('js', new Date());

    gtag('config', 'UA-23581568-13');
</script>
<script defer
    src="https://static.cloudflareinsights.com/beacon.min.js/v652eace1692a40cfa3763df669d7439c1639079717194"
    integrity="sha512-Gi7xpJR8tSkrpF7aordPZQlW2DLtzUlZcumS8dMQjwDHEnw9I7ZLyiOj/6tZStRBGtGgN6ceN6cMH8z7etPGlw=="
    data-cf-beacon='{"rayId":"74f96a835f98ca8c","token":"cd0b4b3a733644fc843ef0b185f98241","version":"2022.8.1","si":100}'
    crossorigin="anonymous"></script>
